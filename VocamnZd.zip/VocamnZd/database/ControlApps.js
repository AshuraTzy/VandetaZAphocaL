module.exports = {
  tokens: "8101843914:AAFGJhAz3T545gRkUWzkZizVPvFkXqiZbrU", 
  owner: "7171660349", 
  port: "9362", // Ini Wajib Jangan Diubah
  ipvps: "https://host.astavvip-tech.xyz" // Jangan Diubah Nanti Eror!!
};